#-------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   Adrianne McAllister
# Date:  05/21/23
# ChangeLog: (Who, When, What)
#   Adrianne McAllister, 05/19/23, Created script
#   Adrianne McAllister, 05/21/23, Added code to complete assignment 5
#-------------------------------------------------#

#-- Data --#
# declare variables and constants
# objFile = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection

#-- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

#-- Processing --#
# Step 1
# When the program starts, load any data you have
# in a text file called ToDo.txt into a python Dictionary.

# Step 2
# Display a menu of choices to the user

# Step 3
# Display all todo items to user

# Step 4
# Add a new item to the list/Table

# Step 5
# Remove a new item to the list/Table

# Step 6
# Save tasks to the ToDo.txt file

# Step 7
# Exit program
#-------------------------------

# Step 1 - Load data from a file
    # When the program starts, load each "row" of data
    # in "ToDo.txt" into a python Dictionary.
    # Add each dictionary "row" to a python list "table"

ObjFileName = open("Todo.txt", "w+")
ObjFileName.write("Clean House" "," "low\n")
ObjFileName.write("Pay Bills" "," "high\n")

with open("Todo.txt", "r") as ObjFileName:
    line1 = ObjFileName.readline()
    line2 = ObjFileName.readline()

dicRow1 = {"Task":line1[:11], "Priority":line1[12:15]}
dicRow2 = {"Task":line2[:9], "Priority":line2[10:14]}

Table1 = [dicRow1, dicRow2]

# Step 2 - Display a menu of choices to the user
menu_item = 0

while menu_item != 5:
    print ("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)

    menu_item = str(input("Which option would you like to perform? [1 to 5] - "))
    print()
# Step 3 -Show the current items in the table\
    if menu_item == '1':
        for row in Table1:
            print(row["Task"] + "," + row["Priority"])

# Step 4 - Add a new item to the list/Table
    elif menu_item == "2":
        strTask = input("Enter a new Task: ")
        strPriority = input("Enter a new Priority: ")
        dicNewRow = {"Task":strTask, "Priority":strPriority}
        Table1.append(dicNewRow)

# Step 5 - Remove a new item from the list/Table
    elif menu_item == "3":
        delKey = int(input("Which row do you want to delete? "))
        del Table1[delKey]

# Step 6 - Save tasks to the ToDo.txt file
    elif menu_item == "4":
        with open("Todo.txt", "w+") as ObjFileName:
            for line in Table1:
                ObjFileName.write(("%s\n" % line))
        print("Data saved!")

    elif menu_item == "5":
        print("Goodbye")
        break
